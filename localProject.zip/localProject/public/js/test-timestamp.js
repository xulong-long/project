var t1 = process.uptime()*1000
var a = 9999
var b
var  i =0, count =100000, interval = 0;
for(i = 0; i< count; i++){
    if(a > i){
        b = i
    }
}
t2 = process.uptime()*1000
interval = t2 - t1
console.log(interval)