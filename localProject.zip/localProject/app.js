// 导入相关库文件
const http = require('http')
const fs = require('fs')
const queryString = require('querystring')
const Web3 = require('web3')
const net = require('net')

const  web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'))

//连接到本地区块链中
// const web3 = new Web3(new Web3.providers.WebsocketProvider('wc://loaclhost:8546'))

const AC_abi = [{
    constant: false,
    inputs: [{
        internalType: "uint256",
        name: "_subject",
        type: "uint256"
    }, {
        internalType: "uint256",
        name: "_object",
        type: "uint256"
    }, {
        internalType: "string",
        name: "_permission",
        type: "string"
    }, {
        internalType: "string",
        name: "_attribute",
        type: "string"
    }],
    name: "AccessControl",
    outputs: [{
        internalType: "bool",
        name: "",
        type: "bool"
    }],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    constant: false,
    inputs: [{
        internalType: "uint256",
        name: "_object",
        type: "uint256"
    }, {
        internalType: "string",
        name: "_character",
        type: "string"
    }, {
        internalType: "string",
        name: "_attribute",
        type: "string"
    }],
    name: "AttributeDelete",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    constant: false,
    inputs: [{
        internalType: "uint256",
        name: "_object",
        type: "uint256"
    }, {
        internalType: "string",
        name: "_character",
        type: "string"
    }, {
        internalType: "string",
        name: "_attributes",
        type: "string"
    }],
    name: "CreateAttributeSet",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    constant: false,
    inputs: [{
        internalType: "address",
        name: "_specificAccount",
        type: "address"
    }, {
        internalType: "string",
        name: "_Character",
        type: "string"
    }, {
        internalType: "uint256",
        name: "_member",
        type: "uint256"
    }],
    name: "CreateCharacterSet",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    constant: false,
    inputs: [{
        internalType: "address",
        name: "_specificAccount",
        type: "address"
    }, {
        internalType: "uint256",
        name: "_object",
        type: "uint256"
    }, {
        internalType: "uint256",
        name: "_subject",
        type: "uint256"
    }, {
        internalType: "string",
        name: "_behaviour",
        type: "string"
    }, {
        internalType: "string",
        name: "_attribute",
        type: "string"
    }],
    name: "MakePolicy",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    inputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "constructor"
}, {
    anonymous: false,
    inputs: [{
        indexed: false,
        internalType: "int256",
        name: "code",
        type: "int256"
    }],
    name: "ErrorCode",
    type: "event"
}, {
    anonymous: false,
    inputs: [{
        indexed: false,
        internalType: "string",
        name: "ERROR",
        type: "string"
    }],
    name: "ErrorMessage",
    type: "event"
}, {
    constant: false,
    inputs: [{
        internalType: "address",
        name: "_manager",
        type: "address"
    }, {
        internalType: "string",
        name: "_name",
        type: "string"
    }, {
        internalType: "address",
        name: "_account",
        type: "address"
    }, {
        internalType: "address",
        name: "_specificAccount",
        type: "address"
    }],
    name: "ManagerRegister",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    anonymous: false,
    inputs: [{
        indexed: false,
        internalType: "bool",
        name: "result",
        type: "bool"
    }],
    name: "returnResult",
    type: "event"
}, {
    constant: false,
    inputs: [{
        internalType: "uint256",
        name: "_MAC",
        type: "uint256"
    }, {
        internalType: "string",
        name: "_CharacterSet",
        type: "string"
    }],
    name: "UserDelete",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    constant: false,
    inputs: [{
        internalType: "uint256",
        name: "_MAC",
        type: "uint256"
    }, {
        internalType: "string",
        name: "_CharacterSet",
        type: "string"
    }],
    name: "UserRegister",
    outputs: [],
    payable: false,
    stateMutability: "nonpayable",
    type: "function"
}, {
    constant: true,
    inputs: [{
        internalType: "uint256",
        name: "_object",
        type: "uint256"
    }],
    name: "getLegth",
    outputs: [{
        internalType: "uint256",
        name: "l",
        type: "uint256"
    }, {
        internalType: "string",
        name: "a",
        type: "string"
    }],
    payable: false,
    stateMutability: "view",
    type: "function"
}]

//
// // console.log(MC_abi)
// web3.eth.net.isListening().then(console.log)
// const AC = new web3.eth.Contract(AC_abi,'0x55dB9Ed643C66A88ba758b05d3D5Df8AAe41EdB9')
//
const account = "0x10b76a7d740CEb6707EB5AC2E2c568DB484675e6"

const specialAccount = "0x10b76a7d740CEb6707EB5AC2E2c568DB484675e6"
//
// web3.personal.unlockAccount(account,'502262',99999)
web3.isConnected(function (err,res){
    if(!err){
        console.log(res)
    }

})

const AC = web3.eth.contract(AC_abi).at('0x5B1b2092B5446d42dc8cAc07eE818A5823FF65dC')
// AC.ManagerRegister(account,'xulong',account,specialAccount,{gas:300000,from:account})
// for(var i=0; i<100; i++){
//     var num = 1043119500+i;
//     AC.CreateCharacterSet(specialAccount,'class1',num,{gas:300000,from:account})
// }
// AC.CreateCharacterSet(specialAccount,'class1',1043119501,{gas:300000,from:account})
// AC.CreateCharacterSet(specialAccount,'class2',1043119504,{gas:300000,from:account})
// AC.UserRegister(1043119501,'class1',{gas:300000,from:account})
// AC.UserRegister(1043119504,'class2',{gas:300000,from:account})
for(var i=0; i<30; i++){
    var attri = 'database'+i
    AC.CreateAttributeSet(1043119504,'class2',attri,{gas:300000,from:account})
}

// AC.CreateAttributeSet(1043119504,'class2','Database2',{gas:300000,from:account})
// AC.MakePolicy(specialAccount,1043119504,1043119501,'read','database',{gas:300000,from:account})
// // var evnet= AC.allEvents({fromBlock:'latest'})
// evnet.watch(function (error,event){
//     if(!error){
//         console.log(event)
//     }
// })
//开启http服务
http.createServer(function(req,res){
    const url = req.url
    console.log(url)

    // if(url === '/MANAGERPOST/'){
    //     let ManagerPost = ''
    //     let ManagerName = ''
    //     let key
    //     let timestamp
    //     let singData
    //     //监听POST请求，会产生data事件
    //     req.on('data',function (chunk) {
    //         ManagerPost += chunk
    //     })
    //     req.on('end',function () {
    //         ManagerPost = queryString.parse(ManagerPost)
    //         ManagerName = ManagerPost.ManagerName
    //         console.log(ManagerName)
    //         MC.methods.ManagerAC_first_step(ManagerName,account).send({from:account})
    //         MC.events.ErrorCode({filter:{}, fromBlock: 'latest'},function(error,event){})
    //             .on('data',function(event){
    //                 let ErrorCode = 404
    //                 ErrorCode = event.returnValues.code
    //                 // console.log(ErrorCode)
    //                 // console.log(ErrorCode == 407)
    //                 ////////////////////////////////////////////ERRORCODE///////////////////////////////////////////////
    //                 if(ErrorCode == 405){
    //                     fs.readFile('./public/HTML/405.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //                 if(ErrorCode == 406){
    //                     fs.readFile('./public/HTML/406.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //                 if(ErrorCode == 407){
    //                     fs.readFile('./public/HTML/407.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //                 if(ErrorCode == 408){
    //                     fs.readFile('./public/HTML/408.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //                 if(ErrorCode == 409){
    //                     fs.readFile('./public/HTML/409.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //                 if(ErrorCode == 410){
    //                     fs.readFile('./public/HTML/410.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //                 if(ErrorCode == 411){
    //                     fs.readFile('./public/HTML/411.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //               /////////////////////////////////////////ERRORCODE/////////////////////////////////////////////////////
    //             })
    //             .on('changed',function(event){})
    //             .on('error',console.error)
    //
    //
    //         MC.events.ManagerAC_and_UserAC_second_step_Event({filter:{}, fromBlock: 'latest'},function(error,event){})
    //             .on('data',function(event){
    //                 console.log(event.returnValues.value)
    //                 if(event.returnValues.value){
    //                     fs.readFile('./public/HTML/managerFunction.html',function (err,page){
    //                         if(err){
    //                             return res.end('404 Not Found!')
    //                         }
    //                         return res.end(page)
    //                     })
    //                 }
    //             })
    //             .on('changed',function(event){})
    //             .on('error',console.error)
    //
    //
    //         MC.events.ManagerAC_first_step_Event({filter:{}, fromBlock: 'latest'},function(error,event){})
    //             .on('data',function(event){
    //                 // console.log(event.returnValues.key,event.returnValues.timestamp)
    //                 key = event.returnValues.key
    //                 timestamp = event.returnValues.timestamp
    //                 // console.log(key,timestamp)
    //                 //use specialAccount to sign
    //                 web3.eth.sign(key,specialAccount,function (err,res){
    //                     if(!err){
    //                         singData = res
    //                         console.log(singData)
    //                         console.log(timestamp)
    //                         console.log(key)
    //                         MC.methods.ManagerAC_and_UserAC_second_step(singData,timestamp,key).send({from:account})
    //                     }
    //                 })
    //             })
    //             .on('changed',function(event){})
    //             .on('error',console.error)
    //
    //         // res.end(ManagerName)
    //     })
    // }

    //开始时跳入到引导页
    if(url === '/'){
        fs.readFile('./public/HTML/AccessControl.html',function(err,data){
            if(err){
                fs.readFile('./public/HTML/404.html',function (err,errorfile) {
                    if(err){
                        return res.end('404 Not Found!')
                    }
                    return res.end(errorfile)
                })

            }
            res.end(data)
        })
    }

    if(url === '/ACCESSCONTROL/'){
        var UserPost = ''
        var subject = ''
        var object = ''
        var action = ''
        var attribute = ''
        // var t1 = 0
        // var t2 = 0
        req.on('data',function (chunk) {
            UserPost += chunk
        })
        req.on('end',function () {
            UserPost = queryString.parse(UserPost)
            subject = UserPost.Subject
            object = UserPost.Object
            action = UserPost.Action
            attribute = UserPost.Attribute
            attribute = attribute.replace(/\s*/g,"")
            // t1 = process.uptime()*1000
            console.log(subject,object,action,attribute)
            // AC.events.allEvents({filter:{},fromBlock:'latest'},function(error,event){}).on('data',function(event){
            //     t2 = process.uptime()*1000
            //     console.log(event)
            //     console.log(t2-t1)
            // })
            // var evnets = AC.returnResult({fromBlock:'latest'})
            // var evnets = AC.allEvents({fromBlock:'latest'})
            // evnets.watch(function (error,event){
            //     if(!error){
            //         console.log(event)
            //         // t2 = process.uptime()*1000
            //         // console.log(t2-t1)
            //         res.end(subject)
            //     }
            // })
            // for(var i=0; i<1; i++){
                // AC.methods.AccessControl(subject, object, action).send({from: account})
            AC.AccessControl(subject, object, action, attribute,{gas:300000, from:account})
            res.end(subject)
            // }

            // console.log(t2-t1)

        })
    }

    if(url === '/connect'){
        fs.readFile('./public/HTML/Connect system.html', function(err,data){
            if(err){
                fs.readFile('./public/HTML/404.html',function (err,erorfile){
                    if(err){
                        return res.end('404 Not Fount')
                    }
                    return res.end(erorfile)
                })
            }
            res.end(data)
        })
    }

    if(url === '/CONNECTSYSTEM/'){
        var UserPost = ''
        var user = ''
        var CLASS = ''
        // var t1 = 0
        // var t2 = 0
        req.on('data',function (chunk){
            UserPost += chunk
        })
        req.on('end',function (){
            UserPost = queryString.parse(UserPost)
            user = UserPost.User
            CLASS = UserPost.CLASS
            CLASS = CLASS.replace(/\s*/g,"")
            // console.log(user,CLASS)
            var evnets1 = AC.returnResult({fromBlock:'latest'})
            // t1 = process.uptime()*1000
            // evnets1.watch(function (error,event){
            //     if(!error){
            //         // console.log(event)
            //         t2 = process.uptime()*1000
            //         console.log(t2-t1)
            //         res.end(user)
            //     }
            // })
            // for(var i=0; i<100; i++){
                AC.UserRegister(user, CLASS,{gas:300000, from:account})
            // }
            // console.log(user,CLASS)


        })
    }
    if(url === '/disconnect'){
        fs.readFile('./public/HTML/Disconnect.html', function(err,data){
            if(err){
                fs.readFile('./public/HTML/404.html',function (err,erorfile){
                    if(err){
                        return res.end('404 Not Fount')
                    }
                    return res.end(erorfile)
                })
            }
            res.end(data)
        })
    }
    if(url === '/DISCONNECTSYSTEM/'){
        var UserPost = ''
        var user = ''
        var CLASS = ''
        // var t1 = 0
        // var t2 = 0
        req.on('data',function (chunk){
            UserPost += chunk
        })
        req.on('end',function (){
            UserPost = queryString.parse(UserPost)
            user = UserPost.User
            CLASS = UserPost.CLASS
            // t1 = process.uptime()*1000
            // console.log(user,CLASS)
            // var evnets1 = AC.returnResult({fromBlock:'latest'})
            // evnets1.watch(function (error,event){
            //     if(!error){
            //         // console.log(event)
            //         t2 = process.uptime()*1000
            //         console.log(t2-t1)
            //         res.end(user)
            //     }
            // })
            // for(var i=0; i<100; i++){
                AC.UserDelete(user, CLASS,{gas:300000, from:account})
            // }

            // res.end(user)
        })
    }
    if(url === '/addattribute'){
        fs.readFile('./public/HTML/AddAttribute.html',function(err,data){
            if(err){
                fs.readFile('./public/HTML/404.html',function (err,errorfile) {
                    if(err){
                        return res.end('404 Not Found!')
                    }
                    return res.end(errorfile)
                })

            }
            res.end(data)
        })
    }

    if(url === '/ADDATTRIBUTE/'){
        var UserPost = ''
        var user = ''
        var CLASS = ''
        var attribute = ''
        // var t1 = 0
        // var t2 = 0
        req.on('data',function (chunk){
            UserPost += chunk
        })
        req.on('end', function (){
            UserPost = queryString.parse(UserPost)
            user = UserPost.User
            CLASS = UserPost.CLASS
            attribute = UserPost.Attribute
            // t1 = process.uptime()*1000
            // console.log(user,CLASS,attribute)
            // var evnets = AC.returnResult({fromBlock:'latest'})
            // evnets.watch(function (error,event){
            //     if(!error){
            //         // console.log(event)
            //         t2 = process.uptime()*1000
            //         console.log(t2-t1)
            //         res.end(user)
            //     }
            // })
            // for(var i=0;i<30;i++){
                AC.CreateAttributeSet(user, CLASS, attribute, {gas:300000, from:account})
            // }
            // res.end(user)
        })

    }

    if(url === '/delattribute'){
        fs.readFile('./public/HTML/DeleAttribute.html',function(err,data){
            if(err){
                fs.readFile('./public/HTML/404.html',function (err,errorfile) {
                    if(err){
                        return res.end('404 Not Found!')
                    }
                    return res.end(errorfile)
                })

            }
            res.end(data)
        })
    }

    if(url === '/DELETEATTRIBUTE/'){
        var UserPost = ''
        var user = ''
        var CLASS =  ''
        var attribute = ''
        var t1 = 0
        var t2 = 0
        req.on('data', function (chunk){
            UserPost += chunk
        })
        req.on('end',function(){
            UserPost = queryString.parse(UserPost)
            user = UserPost.User
            CLASS = UserPost.CLASS
            attribute = UserPost.Attribute
            t1 = process.uptime()*1000
            // console.log(user,CLASS,attribute)
            var evnets1 = AC.returnResult({fromBlock:'latest'})
            evnets1.watch(function (error,event){
                if(!error){
                    // console.log(event)
                    t2 = process.uptime()*1000
                    console.log(t2-t1)
                    res.end(user)
                }
            })
            for(var i=0; i<30;i++){
                var num = 'database'+i
                AC.AttributeDelete(user, CLASS, num, {gas:30000000, from:account})
            }

            // res.end(user)
        })
    }

    //统一处理静态资源
    if(url.indexOf('/public/')=== 0){
        fs.readFile('.'+url,function(err,data){
            if(err){
                fs.readFile('./public/HTML/404.html',function (err,errorfile) {
                    if(err){
                        return res.end('404 Not Found!')
                    }
                    return res.end(errorfile)
                })
            }
            res.end(data)
        })
    }
    // else{
    //     fs.readFile('./public/HTML/404.html',function (err,errorfile) {
    //         if(err){
    //             return res.end('404 Not Found!')
    //         }
    //         return res.end(errorfile)
    //     })
    //
    // }
}).listen(3000,function (err,result) {
    if(err){
        return console.log('error')
    }
    console.log('listening......')

})